<!--<div style="background-color: #ff3333; text-align: center; color: azure">
<h2>Su hosting de servidor está por ser suspendido por falta de pago. Su fecha limite para realizar su pago es: 25/12/2020</h2>
</div>-->
<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="searchSale">
        Buscador de ventas
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                <li class="nav-item">
                        <img src="http://127.0.0.1:8000/logo_inusual.png" height="100%" width="60%" alt="">
                </li>
                
            </ul>
        </div>
    </div>
</nav>

