<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InitialCash extends Model
{
    protected $fillable = [ 'amount' ];
}
