<html>
    <head>
        <style type="text/css">
            table {
                border-collapse: collapse;
            }

            table, th, td {
                border: 1px solid black;
                text-align: center;
                border-color: #424242;
            }
            .backgroundColor{
                background: red;
            }
        </style>
    </head> 
    <body>
        <div style="text-align:center; margin-left: auto; margin-right: auto;">
            
            <h4 >REPORTE DE CORTE DE CAJA</h4>
            <?php $__currentLoopData = $branchOffice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <table style="width: 100%; margin-top:20px;">
                <?php if(Auth::user()->rol_id == 1): ?>
                <tr>
                    <th colspan="9" class="backgroundColor">
                        SUCURSAL
                    </th>
                </tr>
                <tr>
                    <td colspan="9">
                        <?php echo e($b->name); ?>

                    </td>
                </tr>
                <?php else: ?>
                <tr>
                    <th colspan="7" class="backgroundColor">
                        SUCURSAL
                    </th>
                </tr>
                <tr>
                    <td colspan="7">
                        <?php echo e($b->name); ?>

                    </td>
                </tr>
                <?php endif; ?>
                <tr>
                    <th style="font-size: 14px" class="backgroundColor">PRODUCTO</th>
                    <th style="font-size: 14px" class="backgroundColor">CATEGORÍA</th>
                    <th style="font-size: 14px" class="backgroundColor">MARCA</th>
                    <th style="font-size: 14px" class="backgroundColor">CANTIDAD</th>
                    <?php if(Auth::user()->rol_id == 1 ): ?>
                    <th style="font-size: 14px" class="backgroundColor">COSTO</th>  
                    <?php endif; ?>
                    <th style="font-size: 14px" class="backgroundColor">PRECIO <br/> PÚBLICO</th>
                    <th style="font-size: 14px" class="backgroundColor">DESCUENTO</th>
                    <?php if(Auth::user()->rol_id == 1 ): ?>
                    <th style="font-size: 14px" class="backgroundColor">INVERSION</th>  
                    <?php endif; ?>
                    <th style="font-size: 14px" class="backgroundColor">TOTAL</th>
                </tr>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($b->id == $p->sale->branch_office_id ): ?>
                <tr>
                    
                    <td><?php echo e($p->product->name); ?></td>
                    <td><?php echo e($p->product->category->name); ?></td>
                    <?php if($p->product->brand == null): ?>
                    <td>N/A</td>
                    <?php else: ?>
                    <td><?php echo e($p->product->brand->name); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($p->quantity); ?></td>
                    <?php if(Auth::user()->rol_id == 1 ): ?>
                    <td>$<?php echo e($p->product->cost); ?></td>
                    <?php endif; ?>
                    <td>$<?php echo e($p->sale_price); ?></td>
                    <td>$<?php echo e($p->amount_discount * $p->quantity); ?></td>
                    <?php if(Auth::user()->rol_id == 1 ): ?>
                    <td>$<?php echo e($p->product->cost * $p->quantity); ?></td>
                    <?php endif; ?>
                    <td>$<?php echo e($p->total); ?></td> 
                    

                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <table style="width: 100%; margin-top:20px;">
             <!--   <tr>
                    <th>CAJA INICIAL</th>
                    <td>$<?php echo e($cash->caja_inicial); ?></td>
                    <th>CAJA FINAL</th>
                    <td>$<?php echo e(number_format($cash->caja_inicial + $cash->total, 2, '.', '')); ?></td>
                </tr>
                -->
                <tr>
                    <th>TOTAL VENTAS</th>
                    <td>$<?php echo e($cash->subtotal + $card->subtotal); ?></td>
                    <th>DINERO EFECTIVO</th>
                    <td>$<?php echo e($cash->total - $cash->descuento); ?></td>
                    <!--
                    <th>INVERSIÓN</th>
                    <td>$<?php echo e($cash->costo + $card->costo); ?></td>
                    -->
                </tr>
                <tr>
                    
                    <th>DINERO ELECTRÓNICO</th>
                    <td>$<?php echo e($card->total - $card->descuento); ?></td>
                    <th>DESCUENTOS</th>
                    <td>$<?php echo e($cash->descuento + $card->descuento); ?></td>
                    
                </tr>
                <!--<tr>
                    <th>GANANCIA</th>
                    <td>$<?php echo e(($cash->subtotal + $card->subtotal) - ($cash->costo + $card->costo)); ?></td>

                </tr>
                <tr>
                    <th>GASTOS</th>
                    <td colspan="3">$<?php echo e($card->expense); ?></td>
                </tr>-->
            </table>
            <!--  
            

            <h5 style="margin: 20px;">REPORTE GENERADO POR <?php echo e(strtoupper($user->name)); ?></h5>
            <h5 style="margin: 5px;"><?php echo e($date); ?></h5>
            
        </div>
    </body>
</html><?php /**PATH C:\Users\lenovo\Documents\xampp\htdocs\solucionesLabs\resources\views/reports/reportCashClosing.blade.php ENDPATH**/ ?>