<html>
    <head>
        <style type="text/css">
            table {
                border-collapse: collapse;
            }

            table, th, td {
                border: 1px solid black;
                text-align: center;
                border-color: #424242;
                font-size: 12px;
            }
            .backgroundColor{
                background: red;
            }
        </style>
    </head> 
    <body>
        <div style="text-align:center; margin-left: auto; margin-right: auto;">
            
            <h4 >REPORTE DE VENTAS</h4>
            <h5>DESDE <?php echo e($from); ?> HASTA <?php echo e($to); ?></h5>

            <?php $__currentLoopData = $branchOffice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(Auth::user()->rol_id == 1): ?>
            <table style="width: 100%; margin-top:20px;">
                <tr>
                    <th colspan="15" class="backgroundColor">
                        SUCURSAL
                    </th>
                </tr>
                <tr>
                    <td colspan="15">
                        <?php echo e($b->name); ?>

                    </td>
                </tr>
            <?php else: ?>
            <table style="width: 100%; margin-top:20px;">
                <tr>
                    <th colspan="13" class="backgroundColor">
                        SUCURSAL
                    </th>
                </tr>
                <tr>
                    <td colspan="13">
                        <?php echo e($b->name); ?>

                    </td>
                </tr>
            <?php endif; ?>
                <tr>
                    <th style="font-size: 10px" class="backgroundColor">PRODUCTO</th>
                    <th style="font-size: 10px" class="backgroundColor">CATEGORÍA</th>
                    <th style="font-size: 10px" class="backgroundColor">MARCA</th>
                    <th style="font-size: 10px" class="backgroundColor">CANTIDAD</th>
                    <?php if(Auth::user()->rol_id == 1 ): ?>
                    <th style="font-size: 10px" class="backgroundColor">COSTO</th>  
                    <?php endif; ?>
                    <th style="font-size: 10px" class="backgroundColor">PRECIO <br/> PÚBLICO</th>
                    <th style="font-size: 10px" class="backgroundColor">DESCUENTO</th>

                    <?php if(Auth::user()->rol_id == 1 ): ?>
                    <th style="font-size: 10px" class="backgroundColor">INVERSION</th>  
                    <?php endif; ?>
                    <th style="font-size: 10px" class="backgroundColor">TOTAL</th>
                    <th style="font-size: 10px" class="backgroundColor">VENDEDOR</th>
                    <th style="font-size: 10px" class="backgroundColor">FOLIO<br>VENTA</th>
                    <th style="font-size: 10px" class="backgroundColor">CLIENTE</th>
                    <th style="font-size: 10px" class="backgroundColor"># CLIENTE</th>
                    <th style="font-size: 10px" class="backgroundColor">FECHA</th>
                    <th style="font-size: 10px" class="backgroundColor">HORA</th>
                </tr>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($b->id == $p->branch_office_id ): ?>
                    <tr>
                        
                        <td><?php echo e($p->product_name); ?></td>
                        <td><?php echo e($p->category); ?></td>
                        <?php if($p->brand == null): ?>
                        <td>N/A</td>
                        <?php else: ?>
                        <td><?php echo e($p->brand); ?></td>
                        <?php endif; ?>

                        <td><?php echo e($p->quantity); ?></td>
                        <?php if(Auth::user()->rol_id == 1 ): ?>
                        <td>$<?php echo e($p->cost); ?></td>
                        <?php endif; ?>
                        <td>$<?php echo e($p->sale_price); ?></td>
                        <td>$<?php echo e($p->amount_discount * $p->quantity); ?></td>
                        <?php if(Auth::user()->rol_id == 1 ): ?>
                        <td>$<?php echo e($p->cost * $p->quantity); ?></td>
                        <?php endif; ?>
                        <td>$<?php echo e($p->total); ?></td> 
                        <td><?php echo e($p->seller.' '.$p->seller_lastName); ?></td>
                        <td><?php echo e($p->folio); ?></td>
                        <?php if($p->client_id != null): ?>
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($client->id == $p->client_id): ?>
                                    <td><?php echo e($client->name); ?></td>
                                    <td><?php echo e($client->id); ?></td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <td>N/A</td>
                            <td>N/A</td>
                        <?php endif; ?>
                        <td><?php echo e(date('Y-m-d',strtotime($p->date))); ?></td> 
                        <td><?php echo e(date('H:m:s',strtotime($p->date))); ?></td> 


                    </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <table style="width: 100%; margin-top:20px;">
                
                <?php if(Auth::user()->rol_id == 1 ): ?>
                <tr>
                    <th>TOTAL VENTAS</th>
                    <td colspan="3">$<?php echo e($cash->subtotal + $card->subtotal); ?></td>
                    

                </tr>
                <?php else: ?>
                <tr>
                    <th>TOTAL VENTAS</th>
                    <td colspan="3">$<?php echo e($cash->subtotal + $card->subtotal); ?></td>
                </tr>
                <?php endif; ?>

                <tr>
                    <th>DINERO EFECTIVO</th>
                    <td colspan="3">$<?php echo e($cash->total); ?></td>
                </tr>
                <tr>
                    <th>DINERO ELECTRÓNICO</th>
                    <td colspan="3">$<?php echo e($card->total); ?></td>
                </tr>
                <tr>
                    
                    <th>DESCUENTOS</th>
                    <td colspan="3">$<?php echo e($cash->descuento + $card->descuento); ?></td>
                </tr>
                
            </table>

            

            <h5 style="margin: 20px;">REPORTE GENERADO POR <?php echo e(strtoupper($user->name)); ?></h5>
            <h5 style="margin: 5px;"><?php echo e($date); ?></h5>
            
        </div>
    </body>
</html><?php /**PATH C:\Users\lenovo\Documents\xampp\htdocs\solucionesLabs\resources\views/reports/reportBranchOffice.blade.php ENDPATH**/ ?>