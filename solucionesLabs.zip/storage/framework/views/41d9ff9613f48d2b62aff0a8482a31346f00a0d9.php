<!DOCTYPE html>
<html lang="en">
    <?php
$subtotals = 0;
$total =0;
$descuento =0;
$variable;
$title;
if(!empty($sale->shopping_cart_id))
{
    $cliente = $sale->client;
  $variable =  $sale->productsInSale;
  $title = 'Nota de compra';
}
else
{
    $variable =  $sale->productsInQuotes;
    $title = 'Cotizacion';
}
   

?>
<head>
    <meta charset="UTF-8">
    <title><?php echo e($title); ?></title>    
</head>
<body>

<style>
.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
   
}

}
.left{
    margin-left: 0px;
  margin-right: auto;
  margin-top: 0%;
  padding-top: 0%;
}
td,tr,table {
   
    border-collapse: collapse;
}

td.cantidad,th.cantidad {
    word-break: break-all;
}
td.precio,th.precio {
    word-break: break-all;
}
.centrado {
    text-align: center;
    align-content: center;
    width: 100%;
}
img {
    max-width: inherit;
    width: inherit;
}
table.borde
{

  border-collapse:collapse;
}
}
@media  print{
  .oculto-impresion, .oculto-impresion *{
    display: none !important;
  }
}

</style>

<div>
    <table class="borde">
    <thead>
        <th class="borde" > <img class="left" src="<?php echo e(asset('/solucioneslab.png')); ?>" style="width:210px ; height:150px ;" alt="Logotipo"></th>
        <th>   <p class="centrado">
        Calle <?php echo e($sale->branchOffice->address->street); ?>,No <?php echo e($sale->branchOffice->address->ext_number); ?> <br>
        Colonia <?php echo e($sale->branchOffice->address->suburb); ?> <br>
        Tel. 961 141 1395 <br>
        Cel. 961 122 3970 <br>
        Personas Fisicas Con actividades Empresariales y Profesionales
        
    </p></th>
        <th> 
        Fecha: <?php echo e($sale->created_at->format('d-m-y h:m:s')); ?> <br>
        Folio: <?php echo e($sale->id); ?>

    </th>
    </thead>
</table>
<br>
    <?php if(!empty($cliente)): ?>
    Cliente: <?php echo e($cliente->name); ?>  <?php if($cliente->last_name != 'NO APLICA'): ?><?php echo e($cliente->last_name); ?> <?php endif; ?> <?php endif; ?>

    <?php if($title == 'Cotizacion'): ?>
    Cliente: <?php echo e($clientName); ?>

    <hr>
    Esta nota es informativa
    Precios sujetos a cambios sin previo aviso.
    <?php endif; ?>
   <hr>
  
  
    <section style="display: flex; justify-content: space-between; align-items: center;">
        <table style="width: 100%">
            <tr>
                 <thead style="font-size: 80%">
                    <th >CANTIDAD</th>
                       <th >MARCA</th>
                    <th>PRODUCTO</th>
                    <th>PRECIO</th>
                    <th>DESCUENTO</th>
                    <th>TOTAL</th>
            </thead>
            <hr>
            </tr>
           <tbody style="text-align: center;font-size: 76%">
           
               <?php $__currentLoopData = $variable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
               <tr>
                   <td><?php echo e($product->quantity); ?></td>
                   <td><?php echo e($product->product->brand->name); ?></td>
                   <td><?php echo e($product->product->name); ?></td>
                   <td>$<?php echo e(number_format($product->sale_price,2,',','.')); ?></td>
                   <td><?php if($product->discount != 0): ?>$<?php echo e(number_format($product->discount,2,',','.')); ?><?php else: ?>-<?php endif; ?></td>
                   <td>$<?php echo e(number_format($product->subtotal,2,',','.')); ?></td>
                  
               </tr>
               <?php
               $subtotals += $product->sale_price;
               $total += $product->subtotal;
               $descuento += $product->discount;
                ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
        </table>
        
    </section>
    <hr/>

    <div id="total">
        
        <?php if($sale->discount != null): ?>Descuento:  %<?php echo e(number_format($sale->discount,2,'.',',')); ?><?php endif; ?>
      
        <br>
        <?php if($title != 'Cotizacion'): ?>   
         Pago en efectivo
        <?php endif; ?>
         <br>
        Total: $<?php echo e(number_format($total-$descuento,2,'.',',')); ?>

    </div>
    <br>
    <br>
    <br>
    <?php echo e($title); ?>

    <p class="centrado">_____________________________</p>
    <p class="centrado">Firma</p>
    <br/>
    <br/>
    <br/>
   

</div>
</body>
<script>
    window.print();
    window.addEventListener("afterprint", function(event) {
        window.close()
    });
</script>
</html>
<?php /**PATH C:\Users\lenovo\Documents\xampp\htdocs\solucionesLabs\resources\views/sales/ticket_new.blade.php ENDPATH**/ ?>