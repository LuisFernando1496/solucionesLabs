
<?php $__env->startSection('content'); ?>

<div class="container">
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>
    <div style="text-align:right; padding-bottom: 2%;">
        <a href="transfers/create" class="btn btn-outline-primary">Nuevo traspaso</a>
    </div>
    <?php echo $__env->make('tranfers.data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\xampp\htdocs\solucionesLabs\resources\views/tranfers/index.blade.php ENDPATH**/ ?>