
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e($error); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
            <div class="row">
                <div class="col-md-8 col-lg 8 col-xs-12 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h5>Detalles de la transferencia</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-8 col-lg-8 col-xs-12 col-sm-12">
                                    <table class="table table-striped" style="width: 100%;">
                                        <thead class="black white-text">
                                            <tr>
                                                <th scope="col">Código</th>
                                                <th scope="col">Nombre</th>
                                                <th scope="col">Marca</th>
                                                <th scope="col">Cantidad traspasada</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $transfer->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->product->bar_code); ?></td>
                                                <td><?php echo e($item->product->name); ?></td>
                                                <td><?php echo e($item->product->brand->name); ?></td>
                                                <td><?php echo e($item->quantity); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-md-4 col-xs-12 col-lg-4 col-sm-12">
                                    <ul class="list-group">
                                        <li class="list-group-item">
                                            <strong>Hecho por: </strong> <span><?php echo e($transfer->user->name); ?> <?php echo e($transfer->user->last_name); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <?php if($transfer->status == 'Enviado'): ?>
                                            <strong>Estatus: </strong> <span style="background-color:#AEEA00; color: white;"><strong><?php echo e($transfer->status); ?></strong></span>
                                            <?php else: ?>
                                            <strong>Estatus: </strong> <span style="background-color:#00C853; color: white;"><strong><?php echo e($transfer->status); ?></strong></span>
                                            <?php endif; ?>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Sucursal destino: </strong> <span><?php echo e($transfer->branchOffice->name); ?></span>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Detalles: </strong> <span><?php echo e($transfer->details); ?></span>
                                        </li>

                                        <li class="list-group-item">
                                            <?php if($transfer->destination_branch_office_id == auth()->user()->branch_office_id
                                            && $transfer->status == 'Enviado'): ?>
                                            <center>
                                                <td>
                                                    <form action="<?php echo e(asset('transfers/'.$transfer->id)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <button type="submit" class="btn btn-outline-success">
                                                            Recibido
                                                        </button>
                                                    </form>
                                                </td>
                                            </center>
                                            <?php endif; ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lenovo\Documents\xampp\htdocs\solucionesLabs\resources\views/tranfers/details.blade.php ENDPATH**/ ?>